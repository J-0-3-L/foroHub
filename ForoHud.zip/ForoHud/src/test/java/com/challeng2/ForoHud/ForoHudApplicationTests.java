package com.challeng2.ForoHud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ForoHudApplicationTests {

	@Test
	void contextLoads() {
	}

}
